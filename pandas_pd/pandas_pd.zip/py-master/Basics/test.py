def sum(a,b):
    return a+b

n1=input('enter first number: ')
n1=int(n1)
n2=input('enter first number: ')
n2=int(n2)
print('sum is: ',sum(n1,n2))
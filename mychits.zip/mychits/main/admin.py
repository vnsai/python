from django.contrib import admin
from .models import Chit, Member, MonthDetail

# Register your models here.



admin.site.register(Chit)
admin.site.register(Member)
admin.site.register(MonthDetail)




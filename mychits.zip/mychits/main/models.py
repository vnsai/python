from django.db import models
from datetime import date

# Create your models here.

class Chit(models.Model):
	chitnumber = models.IntegerField(primary_key=True)
	amount = models.IntegerField()
	months = models.IntegerField()
	start_month = models.DateField()
	end_month = models.DateField()
	number_of_members = models.IntegerField()
	monthly_instalment = models.IntegerField()

	def __str__(self):
		return str(self.chitnumber)

class Member(models.Model):
	chitnumber = models.ManyToManyField(Chit)
	memberid = models.IntegerField(primary_key=True)
	name = models.CharField(max_length=50)
	address = models.TextField(blank=True)
	phone = models.CharField(max_length=25, blank=True)
	email = models.EmailField(max_length=75, blank = True)
	comments = models.TextField(blank=True)
	
	
	def __str__(self):
		return str(self.memberid)

class MonthDetail(models.Model):
	chitnumber = models.ForeignKey(Chit, on_delete=models.CASCADE)
	memberid = models.ForeignKey(Member, on_delete=models.CASCADE)
	monthno = models.IntegerField(blank=True)
	month = models.DateField()
	withdrawn = models.BooleanField(default=False)
	instalment = models.IntegerField(blank=True)
	paidon = models.DateField(blank=True)
	comments = models.TextField(blank=True)
	balance = models.IntegerField(blank=True)

	def __str__(self):
		return str(self.month)
